namespace TextCore
def greet (s : String) : String := "Hello, " ++ s
end TextCore
