def twice (n : Nat) : Nat := n + n
