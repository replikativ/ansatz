import MathCore
import «Text.Core»

def answer (n : Nat) : Nat := twice n + 1
def echo (s : String) : String := TextCore.greet s
def main : IO Unit := IO.println (echo "Lean/JVM")
