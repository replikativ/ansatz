(require '[prototype.import-ir :as ir] '[prototype.runtime-abi :as abi]
         '[prototype.machine :as m] '[clojure.java.io :as io] '[clojure.data.json :as json])
(import '[java.security MessageDigest])
(defn sha [file]
  (let [digest (MessageDigest/getInstance "SHA-256") buffer (byte-array 65536)]
    (with-open [input (io/input-stream file)]
      (loop [] (let [n (.read input buffer)] (when (pos? n) (.update digest buffer 0 n) (recur)))))
    (apply str (map #(format "%02x" (bit-and 255 %)) (.digest digest)))))
(defn reference-value [world value]
  (cond (m/ref? value)
        (let [node (m/node world value) layout (:layout node)
              extent (+ (* 8 (or (:usize layout) 0)) (or (:ssize layout) 0))]
          {:tag (:tag node) :fields (mapv #(reference-value world %) (:fields node))
           :scalar-bytes (mapv #(get (:scalar-bytes node) (+ (* 8 (or (:objects layout) 0)) %) 0) (range extent))})
        (instance? prototype.machine.Tag value) (:tag value)
        :else value))
(def archive-root (io/file (first *command-line-args*)))
(defn original [path] (io/file archive-root path))
(defn setup [path labels]
  (let [catalogue (ir/index-bundles [(str (original path))])
        by-label (into {} (map (fn [name] [(ir/name-label name) name]) (keys (:declarations catalogue))))
        names (mapv #(or (get by-label %) (throw (ex-info "Missing original declaration" {:label %}))) labels)]
    {:names names :functions (ir/load-closure catalogue names abi/lower)}))
(defn run! [world entry arguments budget]
  (let [world (m/run (m/start world entry arguments) budget)]
    (assert (= :done (:status world)) (pr-str (select-keys world [:status :stats]))) world))
(def rb-path "test/fixtures/unchanged-programs/rbmap.jsonl")
(def mc-path "test/fixtures/unchanged-programs/compiler-ir.jsonl")
(def rb-setup (setup rb-path ["mkMap" "fold._redArg" "main._closed_0"]))
(def rb-seed (run! (m/world (:functions rb-setup)) (nth (:names rb-setup) 2) [] 10000))
(def rb-values
  (mapv (fn [n]
          (let [[make fold _] (:names rb-setup)
                tree (run! rb-seed make [n] 2000000)
                done (run! tree fold [(:result rb-seed) (:result tree) 0] 2000000)]
            (println :historical-world-rbmap n)
            {:n n :tree (reference-value tree (:result tree)) :result (:result done)
             :allocations (get-in done [:stats :allocations]) :field-stores (get-in done [:stats :field-stores])}))
        [0 1 11 100 300 1000]))
(def mc-labels (with-open [reader (io/reader (original mc-path))]
                 (->> (line-seq reader) (map #(json/read-str %)) (filter #(= "decl" (get % "kind")))
                      (mapv #(get % "name")))))
(assert (= 81 (count mc-labels)))
(def mc-setup (setup mc-path (mapv ir/name-label mc-labels)))
(def mc-values
  (mapv (fn [entry]
          (let [world (run! (m/world (:functions mc-setup)) entry [] 100000)]
            {:name entry :label (ir/name-label entry) :value (reference-value world (:result world))})) mc-labels))
(def source-files
  (into (sorted-map)
    (for [file (file-seq (original "src/prototype")) :when (.isFile file)]
      [(str (.relativize (.toPath archive-root) (.toPath file))) {:sha256 (sha file) :bytes (.length file)}])))
(def report {:schema "historical-world-regression-oracles/1"
             :oracle-kind :archived-clojure-world-interpreter
             :source-commit "4ace73f0eb66962bdd17464821ddfc6dadbf195c"
             :archive-source-root "research/lean-hosting"
             :not-a-native-lean-oracle true :generated-by-new-java-engine false
             :inputs {rb-path {:sha256 (sha (original rb-path))} mc-path {:sha256 (sha (original mc-path))}}
             :world-source-inventory source-files :rbmap rb-values :mcmc mc-values})
(def output (second *command-line-args*))
(assert output)
(spit output (pr-str report))
(println :historical-world-oracle-capture {:rbmap (count rb-values) :mcmc (count mc-values)
                                          :bytes (.length (io/file output)) :sha256 (sha output)})
